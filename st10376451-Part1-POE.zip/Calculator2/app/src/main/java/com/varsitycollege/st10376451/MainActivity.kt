package com.varsitycollege.st10376451

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.BigDecimal

class MainActivity : AppCompatActivity() {
    private var number1: TextView? = null
    private var number2: TextView? = null
    private var answer: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        number1 = findViewById(R.id.number1)
        number2 = findViewById(R.id.number2)
        answer = findViewById(R.id.tvAnswer)

        val btnAddition = findViewById<Button>(R.id.btnAddition)
        val btnSubt = findViewById<Button>(R.id.btnSubt)
        val btnMultip = findViewById<Button>(R.id.btnMultip)
        val btnDivis = findViewById<Button>(R.id.btnDivis)
        val btnSquareR = findViewById<Button>(R.id.btnSquareR)
        val btnPower = findViewById<Button>(R.id.btnPower)
        val btnStats = findViewById<Button>(R.id.btnStats)

        btnAddition.setOnClickListener {
            Addition()
        }
        btnSubt.setOnClickListener {
            SUBTRACTION()
        }
        btnMultip.setOnClickListener {
            MULTIPLICATION()
        }
        btnDivis.setOnClickListener {
            DIVISION()
        }
        btnSquareR.setOnClickListener {
            SQUAREROOT()
        }
        btnPower.setOnClickListener {
            POWER()
        }
        btnStats.setOnClickListener {
            STATISTICS()
        }

    }

    private fun STATISTICS() {
        TODO("Not yet implemented")

    }

    private fun POWER() {
        TODO("Not yet implemented")
    }

    private fun SQUAREROOT() {
        TODO("Not yet implemented")
    }


    private fun DIVISION() {

        if (inputIsNotEmpty()) {
            val input1 =
                number1?.text.toString().trim().toBigDecimal()
            val input2 =
                number2?.text.toString().trim().toBigDecimal()
            if(input2.compareTo(BigDecimal.ZERO)== 0 ||input1.compareTo(BigDecimal.ZERO)== 0 ){
                answer?.text = "error"
            }else{
                val result = input1/input2
                answer?.text = "${result}"

            }
        }
    }

    private fun MULTIPLICATION()
    {
        if (inputIsNotEmpty()) {
            val input1 =
                number1?.text.toString().trim().toBigDecimal()
            val input2 =
                number2?.text.toString().trim().toBigDecimal()
            answer?.text =
                input1.multiply(input2).toString()
        }
    }

    private fun SUBTRACTION()
    {
        if (inputIsNotEmpty()) {
            val input1 =
                number1?.text.toString().trim().toBigDecimal()
            val input2 =
                number2?.text.toString().trim().toBigDecimal()
            answer?.text =
                input1.subtract(input2).toString()
        }
    }

    private fun Addition()
    {

        if (inputIsNotEmpty()) {
            val input1 =
                number1?.text.toString().trim().toBigDecimal()
            val input2 =
                number2?.text.toString().trim().toBigDecimal()
            answer?.text =
                input1.add(input2).toString()
        }

        }

    private fun inputIsNotEmpty(): Boolean {
        var b = true
        if (number1?.text.toString().trim().isEmpty()){
            number1?.error = "Required"
            b = false
        }
        if (number2?.text.toString().trim().isEmpty()){
            number2?.error = "Required"
            b = false
        }

        return b
    }

}



